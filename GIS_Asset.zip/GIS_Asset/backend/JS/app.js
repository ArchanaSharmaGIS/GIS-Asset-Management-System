
    
        // const BASE_URL = "<?php echo base_url('index.php/'); ?>";
    
const icons = {
  Good: L.icon({
    iconUrl: ICONS.Good,
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  }),
  Damaged: L.icon({
    iconUrl: ICONS.Damaged,
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  }),
  "Needs Repair": L.icon({
    iconUrl: ICONS["Needs Repair"],
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  })
};

const defaultIcon = icons.Good;


        let assetMarkers = {};
        

function toggleTheme() {
    const body = document.body;
    const isDark = body.getAttribute("data-theme") === "dark";
    body.setAttribute("data-theme", isDark ? "light" : "dark");

    // Force Chart.js defaults update
    Chart.defaults.color = getComputedStyle(document.documentElement)
        .getPropertyValue('--chart-text').trim();

    Chart.defaults.borderColor = getComputedStyle(document.documentElement)
        .getPropertyValue('--chart-grid').trim();

setTimeout(() => {
    updateCharts(
        Number(totalCount.innerText) -
        Number(damagedCount.innerText) -
        Number(repairCount.innerText),
        Number(damagedCount.innerText),
        Number(repairCount.innerText)
    );
}, 50);
}

        var map = L.map('map').setView([23, 77], 6);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

       
        // let markerLayer = L.layerGroup().addTo(map);
        const markerLayer = L.markerClusterGroup({
  spiderfyOnMaxZoom: true,
  showCoverageOnHover: false,
  zoomToBoundsOnClick: true,
  maxClusterRadius: 100
});

map.addLayer(markerLayer);



        L.control({
            position: 'bottomright'
        }).onAdd = function() {
            let div = L.DomUtil.create('div', 'legend');
            div.innerHTML = `
        <b>Legend</b><br>
        <img src="assets/green.png"> Good<br>
        <img src="assets/yellow.png"> Needs Repair<br>
        <img src="assets/red.png"> Damaged
    `;
            return div;
        };


        map.on('click', function(e) {

            var name = document.getElementById('asset_name').value;
            var condition = document.getElementById('condition').value;

            if (!name) {
                alert("Please enter asset name");
                return;
            }

            fetch(API.add, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        name: name,
                        condition: condition,
                        lat: e.latlng.lat,
                        lng: e.latlng.lng
                    })
                })










                .then(res => res.json())
                .then(resp => {
                    if (resp.status === 'success') {
                        // alert("Asset saved successfully");
                        showSuccess("Asset saved successfully");

                        loadAssets();
                    }
                });
        });

        let barChart, pieChart;
function createIcon(type) {
  return L.divIcon({
    className: `custom-marker ${type.replace(" ", "-").toLowerCase()}`,
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  });
}



    function loadAssets() {

  let filter = document.getElementById('filter_condition').value;
  let url = API.list;

  if (filter !== "") {
    url += "?condition=" + encodeURIComponent(filter);
  }

  markerLayer.clearLayers();
  assetMarkers = {};

  let total = 0, good = 0, damaged = 0, repair = 0;

  fetch(url)
    .then(res => res.json())
    .then(data => {



data.features.forEach(feature => {

  let id = feature.properties.id;
  let name = feature.properties.name;

  const rawCondition = feature.properties.condition;
  const condition = rawCondition.trim().toLowerCase();

  let lng = feature.geometry.coordinates[0];
  let lat = feature.geometry.coordinates[1];

  total++;
  if (condition === "good") good++;
  else if (condition === "damaged") damaged++;
  else if (condition === "needs repair") repair++;

let markerClass = '';
if (condition === "damaged") markerClass = 'damaged';
else if (condition === "needs repair") markerClass = 'needs-repair';

const icon = L.divIcon({
  className: `custom-marker-wrapper ${markerClass}`,  // add condition class here
  html: `
    <div class="marker-ring ${condition === 'damaged' ? 'pulse-ring' : ''}"></div>
    <img src="${ICONS[condition]}" class="marker-img" alt="${condition}">
  `,
  iconSize: [40, 40],     // slightly larger to fit ring
  iconAnchor: [20, 40],   // center bottom
  popupAnchor: [0, -40]
});

const marker = L.marker([lat, lng], { icon });

// Optional: still add class to the outer element if needed
marker.on('add', () => {
  const el = marker.getElement();
  if (el) {
    // Can add extra classes here if you want
  }
});

  marker.on('add', () => {
    const el = marker.getElement();
    if (!el) return;

    if (condition === "damaged") el.classList.add("pulse");
    if (condition === "needs repair") el.classList.add("blink");
  });


  

    marker.bindPopup(`
                    <b>${name}</b><br>
                    Condition: ${condition}<br><br>

                    <button class="btn btn-sm btn-warning"
                        onclick="editAsset(${id}, '${name}', '${condition}')">
                        Edit
                    </button>

                    <button class="btn btn-sm btn-danger ms-2"
                        onclick="deleteAsset(${id})">
                        Delete
                    </button>
                `);

  markerLayer.addLayer(marker);
});



    
      document.getElementById('totalCount').innerText = total;
      document.getElementById('goodCount').innerText = good;
      document.getElementById('damagedCount').innerText = damaged;
      document.getElementById('repairCount').innerText = repair;

      updateCharts(good, damaged, repair);
    });
}


        loadAssets();

        
function syncChartTheme() {
    const styles = getComputedStyle(document.documentElement);

    const textColor = styles.getPropertyValue('--chart-text').trim();
    const gridColor = styles.getPropertyValue('--chart-grid').trim();
    const tooltipBg = styles.getPropertyValue('--chart-tooltip-bg').trim();

    Chart.defaults.color = textColor;
    Chart.defaults.borderColor = gridColor;

    Chart.defaults.plugins.tooltip = {
        backgroundColor: tooltipBg,
        titleColor: textColor,
        bodyColor: textColor,
        borderColor: gridColor,
        borderWidth: 1
    };
}


function updateCharts(good, damaged, repair) {

    const isDark = document.body.getAttribute("data-theme") === "dark";

    const textColor = isDark ? "#e5e7eb" : "#1e293b";
    const gridColor = isDark ? "rgba(255,255,255,0.25)" : "rgba(0,0,0,0.1)";
    const tooltipBg = isDark ? "#020617" : "#ffffff";

    if (barChart) barChart.destroy();
    if (pieChart) pieChart.destroy();

    barChart = new Chart(document.getElementById('barChart'), {
        type: 'bar',
        data: {
            labels: ['Good', 'Damaged', 'Needs Repair'],
            datasets: [{
                data: [good, damaged, repair],
                backgroundColor: ['#10b981', '#ef4444', '#f59e0b']
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    labels: { color: textColor }
                },
                tooltip: {
                    backgroundColor: tooltipBg,
                    titleColor: textColor,
                    bodyColor: textColor,
                    borderColor: gridColor,
                    borderWidth: 1
                }
            },
            scales: {
                x: {
                    ticks: { color: textColor },
                    grid: { color: gridColor }
                },
                y: {
                    ticks: { color: textColor },
                    grid: { color: gridColor }
                }
            }
        }
    });

    pieChart = new Chart(document.getElementById('pieChart'), {
        type: 'pie',
        data: {
            labels: ['Good', 'Damaged', 'Needs Repair'],
            datasets: [{
                data: [good, damaged, repair],
                backgroundColor: ['#10b981', '#ef4444', '#f59e0b']
            }]
        },
        options: {
            plugins: {
                legend: {
                    labels: { color: textColor }
                },
                tooltip: {
                    backgroundColor: tooltipBg,
                    titleColor: textColor,
                    bodyColor: textColor
                }
            }
        }
    });
}






        function applySummaryFilter(condition) {

            // Set dropdown value automatically
            document.getElementById('filter_condition').value = condition;

            // Reload map using existing logic
            loadAssets();
        }

        function deleteAsset(id) {
            document.getElementById('delete_id').value = id;
            new bootstrap.Modal(document.getElementById('deleteModal')).show();
        }

        function confirmDelete() {

            let id = document.getElementById('delete_id').value;

            fetch(API.delete + id, {
                    method: 'DELETE'
                })
                .then(res => res.json())
                .then(() => {
                    bootstrap.Modal.getInstance(deleteModal).hide();
                    let modal = bootstrap.Modal.getInstance(
                        document.getElementById('deleteModal')
                    );
                    modal.hide();

                    showSuccess("Asset deleted");
                    loadAssets();
                });
        }

          function editAsset(id, name, condition) {

            document.getElementById('edit_id').value = id;
            document.getElementById('edit_name').value = name;
            document.getElementById('edit_condition').value = condition;

            new bootstrap.Modal(document.getElementById('editModal')).show();
        }

        function showSuccess(msg) {
            document.getElementById('successMessage').innerText = msg;
            new bootstrap.Modal(document.getElementById('successModal')).show();
        }


        function showSuccess(msg) {
            document.getElementById('successMessage').innerText = msg;
            new bootstrap.Modal(document.getElementById('successModal')).show();
        }

        function saveEdit() {

            fetch(API.update, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        id: document.getElementById('edit_id').value,
                        name: document.getElementById('edit_name').value,
                        condition: document.getElementById('edit_condition').value
                    })
                })
                .then(res => res.json())
                .then(() => {
                    // bootstrap.Modal.getInstance(editModal).hide();
                    let modal = bootstrap.Modal.getInstance(
                        document.getElementById('editModal')
                    );
                    modal.hide();

                    showSuccess("Asset updated");
                    loadAssets();
                });
        }


        function viewHistory(id) {
    fetch(API.history + id)
        .then(res => res.json())
        .then(data => {
            let html = "<ul>";
            data.forEach(h => {
                html += `<li>
                    ${h.old_condition} → ${h.new_condition}
                    <br><small>${h.changed_at}</small>
                </li>`;
            });
            html += "</ul>";

            document.getElementById('historyBody').innerHTML = html;
            new bootstrap.Modal(document.getElementById('historyModal')).show();
        });
}

    
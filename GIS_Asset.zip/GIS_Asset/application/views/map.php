<!DOCTYPE html>
<html>

<head>
    <title>Smart GIS Asset Manager</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Leaflet -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css">
    <link
  rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
/>

<link rel="stylesheet" href="<?= base_url('backend/CSS/map.css') ?>">  
<link
  rel="stylesheet"
  href="https://unpkg.com/leaflet.markercluster/dist/MarkerCluster.css"
/>
<link
  rel="stylesheet"
  href="https://unpkg.com/leaflet.markercluster/dist/MarkerCluster.Default.css"
/>


</head>
<body>
  <body data-theme="dark">

    <div class="container-fluid h-100">
  <div class="row h-100">

  <nav class="navbar px-3 py-2">
    <div class="container-fluid">
        <span class="navbar-brand fw-bold fs-5">
            <i class="fas fa-globe-americas me-2 text-primary"></i>
            Smart GIS Asset Manager
        </span>

        <div class="d-flex gap-3 mx-auto">
            <div class="card summary-card border-start border-4 border-success" onclick="applySummaryFilter('')">
                <small class="text-muted">Total</small>
                <h5 id="totalCount" class="mb-0 fw-bold">0</h5>
            </div>
            <div class="card summary-card border-start border-4 border-success" onclick="applySummaryFilter('Good')">
                <small class="text-muted">Good</small>
                <h5 id="goodCount" class="mb-0 fw-bold text-success">0</h5>
            </div>
            <div class="card summary-card border-start border-4 border-warning" onclick="applySummaryFilter('Needs Repair')">
                <small class="text-muted">Repair</small>
                <h5 id="repairCount" class="mb-0 fw-bold text-warning">0</h5>
            </div>
            <div class="card summary-card border-start border-4 border-danger" onclick="applySummaryFilter('Damaged')">
                <small class="text-muted">Damaged</small>
                <h5 id="damagedCount" class="mb-0 fw-bold text-danger">0</h5>
            </div>
        </div>
 <a href="<?= base_url('index.php/assets/export_csv') ?>"
   class="btn btn-outline-primary btn-sm" id="export">
   Export CSV
</a>

<div class="ripple-ring"></div>
<button
  class="btn btn-outline-secondary btn-sm px-3 rounded-pill btn-theme-toggle"
  onclick="toggleTheme()"
>
  <i class="fa-solid fa-moon"></i>
  <span class="mx-1">/</span>
  <i class="fa-solid fa-sun"></i>
</button>

    </div>
</nav>
    <!-- SIDEBAR -->
    <div class="col-md-3 sidebar d-flex flex-column">
         <div class="card-body">
            <h6 class="fw-semibold">Add Asset</h6>

            <div class="mb-2">
                <label class="form-label">Asset Name</label>
                <input type="text" id="asset_name"
                       class="form-control" placeholder="Tree-01">
            </div>

            <div class="mb-2">
                <label class="form-label">Condition</label>
                <select id="condition" class="form-select">
                    <option>Good</option>
                    <option>Damaged</option>
                    <option>Needs Repair</option>
                </select>
            </div>

            <div class="alert alert-info small mb-0">
                Click on map to save location
            </div>
        </div>
  
 

        <!-- Add Asset -->
        <!-- Filter -->
             <!-- FILTER -->
    <div class="card">
        <div class="card-body">
            <h6 class="fw-semibold">Filter Assets</h6>
            <select id="filter_condition" class="form-select mb-2">
                <option value="">All</option>
                <option>Good</option>
                <option>Damaged</option>
                <option>Needs Repair</option>
            </select>

            <button class="btn btn-primary w-100"
                    onclick="loadAssets()">
                Apply Filter
            </button>
        </div>
    </div>

        <!-- Charts -->
          <div class="col-md-12">
                    <div class="card shadow-sm h-100">
                        <div class="card-header fw-semibold">
                            Condition Distribution
                        </div>
                        <div class="card-body">
                            <canvas id="pieChart" height="180"></canvas>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card shadow-sm h-100">
                        <div class="card-header fw-semibold">
                            Asset Condition Overview
                        </div>
                        <div class="card-body">
                            <canvas id="barChart" height="180"></canvas>
                        </div>
                    </div>
                </div>

               

    </div>

    <!-- MAP -->
    <div class="col-md-9 p-0">
        <div id="map"></div>
    </div>

  </div>
</div>


<!-- MODALS -->
 <div class="modal fade" id="deleteModal" tabindex="-1">
  <div class="modal-dialog modal-sm modal-dialog-centered">
    <div class="modal-content">

      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title">Confirm Delete</h5>
      </div>

      <div class="modal-body text-center">
        Are you sure?
        <input type="hidden" id="delete_id">
      </div>

      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">No</button>
        <button class="btn btn-danger" onclick="confirmDelete()">Yes</button>
      </div>

    </div>
  </div>
</div>
<div class="modal fade" id="editModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Edit Asset</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <input type="hidden" id="edit_id">

        <div class="mb-3">
          <label class="form-label">Asset Name</label>
          <input type="text" id="edit_name" class="form-control">
        </div>

        <div class="mb-3">
          <label class="form-label">Condition</label>
          <select id="edit_condition" class="form-select">
            <option>Good</option>
            <option>Damaged</option>
            <option>Needs Repair</option>
          </select>
        </div>
      </div>

      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary" onclick="saveEdit()">Save</button>
      </div>

    </div>
  </div>
</div>
<div class="modal fade" id="successModal" tabindex="-1">
  <div class="modal-dialog modal-sm modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title">Success</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body text-center" id="successMessage">
        Done
      </div>
    </div>
  </div>
</div>
<img class="leaflet-marker-icon pulse">
<img class="leaflet-marker-icon blink">


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- <script src="https://cdn.jsdelivr.net/npm/cart.js"></script -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1"></script>
 

  


<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet.markercluster/dist/leaflet.markercluster.js"></script>


<script>
  const BASE_URL = "<?= base_url('index.php/') ?>";

  const API = {
    list: BASE_URL + "Assets/listing",
    add: BASE_URL + "assets/add",
    update: BASE_URL + "assets/update",
    delete: BASE_URL + "assets/delete/",
    history: BASE_URL + "assets/history/"
  };

  const ICONS = {
    good: "<?= base_url('backend/darkgreen.png') ?>",
    damaged: "<?= base_url('backend/red1.png') ?>",
    "needs repair": "<?= base_url('backend/yellow1.png') ?>"
  };
</script>

<script src="<?= base_url('backend/JS/app.js') ?>"></script>


</body>

</html>
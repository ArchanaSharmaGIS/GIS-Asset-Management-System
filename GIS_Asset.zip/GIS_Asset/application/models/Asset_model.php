<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Asset_model extends CI_Model {

    public function add_asset($data) {
        $sql = "INSERT INTO assets (name, condition, geom)
                VALUES (?, ?, ST_SetSRID(ST_MakePoint(?, ?), 4326))";
        return $this->db->query($sql, [
            $data['name'],
            $data['condition'],
            $data['lng'],
            $data['lat']
        ]);
    }

    public function get_assets() {
        $sql = "SELECT id, name, condition,
                ST_AsGeoJSON(geom) AS geom
                FROM assets";
        $query = $this->db->query($sql);

        return $query->result_array();
    }
}

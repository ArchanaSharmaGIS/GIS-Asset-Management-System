<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Assets extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Asset_model');
    }

    public function index()
    {
        $this->load->view('map');
    }

    // AJAX: ADD ASSET
    public function add()
    {
        $this->output->set_content_type('application/json');

        $input = json_decode($this->input->raw_input_stream, true);

        if (empty($input)) {
            $this->output
                ->set_status_header(400)
                ->set_output(json_encode([
                    'status' => 'error',
                    'message' => 'Invalid input'
                ]));
            return;
        }

        $this->Asset_model->add_asset($input);

        $this->output->set_output(json_encode([
            'status' => 'success'
        ]));
    }

public function listing()
{
    $condition = $this->input->get('condition');

    $this->db->select("
        id,
        name,
        condition,
        ST_AsGeoJSON(geom) as geom
    ");
    $this->db->from('assets');

    if (!empty($condition)) {
        $this->db->where('condition', $condition);
    }

    $query = $this->db->get();

    $features = [];

    foreach ($query->result() as $row) {
        $features[] = [
            "type" => "Feature",
            "geometry" => json_decode($row->geom),
            "properties" => [
                "id" => $row->id,
                "name" => $row->name,
                "condition" => $row->condition
            ]
        ];
    }

    echo json_encode([
        "type" => "FeatureCollection",
        "features" => $features
    ]);
}

public function delete($id) {
    $this->db->where('id', $id)->delete('assets');
    echo json_encode(['status' => 'success']);
}


public function update()
{
    $data = json_decode(file_get_contents("php://input"), true);

    $id = $data['id'];
    $name = $data['name'];
    $new_condition = $data['condition'];

    // 1️⃣ Get OLD asset data
    $asset = $this->db
        ->where('id', $id)
        ->get('assets')
        ->row();

    if (!$asset) {
        echo json_encode(['status' => 'error']);
        return;
    }

    // 2️⃣ Save history BEFORE update
    $this->db->insert('asset_history', [
        'asset_id' => $id,
        'old_condition' => $asset->condition,
        'new_condition' => $new_condition
    ]);

    // 3️⃣ Update asset
    $this->db->where('id', $id)->update('assets', [
        'name' => $name,
        'condition' => $new_condition
    ]);

    echo json_encode(['status' => 'success']);
}
public function history($asset_id)
{
    $history = $this->db
        ->where('asset_id', $asset_id)
        ->order_by('changed_at', 'DESC')
        ->get('asset_history')
        ->result();

    echo json_encode($history);
}




public function export_csv()
{
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="assets.csv"');

    $assets = $this->db->select("
        id,
        name,
        condition,
        ST_Y(geom) as lat,
        ST_X(geom) as lng
    ")->get('assets')->result();

    $output = fopen('php://output', 'w');

    fputcsv($output, ['ID', 'Name', 'Condition', 'Latitude', 'Longitude']);

    foreach ($assets as $a) {
        fputcsv($output, [
            $a->id,
            $a->name,
            $a->condition,
            $a->lat,
            $a->lng
        ]);
    }

    fclose($output);
    exit; // 🔑 VERY IMPORTANT
}



}
